package com.cg.crud.exception;

public class AuthorException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1892452856656092444L;

	public AuthorException(String message) {
		super(message);
	}

	
}
