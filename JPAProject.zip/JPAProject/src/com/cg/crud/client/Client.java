package com.cg.crud.client;

import java.util.List;
import java.util.Scanner;

import com.cg.crud.bean.Author;
import com.cg.crud.exception.AuthorException;
import com.cg.crud.service.AuthorServiceImpl;
import com.cg.crud.service.IAuthorService;

public class Client {
	
	public static void main(String[] args) throws AuthorException {
		
		String firstName;
		String middleName;
		String lastName;
		String mobileNo;
		
		Scanner scInput = new Scanner(System.in);
		
		while(true){
			
	
		System.out.println("1. Add Author");
		System.out.println("2. Delete Author");
		System.out.println("3. Find Author");
		System.out.println("4. Display All Author");
		System.out.println("5. Update Author");
		System.out.println("6. Exit");
		
		String id;
		int ID;
		int choice;
		choice = scInput.nextInt();
		scInput.nextLine();
		
		Author author = new Author();
		IAuthorService authorService = new AuthorServiceImpl();
		
		switch(choice){
		
			case 1 : 
						System.out.println("Enter FirstName of Author : ");
						firstName = scInput.nextLine();
						System.out.println("Enter MiddleName of Author : ");
						middleName = scInput.nextLine();
						System.out.println("Enter LastName of Author : ");
						lastName = scInput.nextLine();
						System.out.println("Enter MobileNo of Author : ");
						mobileNo = scInput.nextLine();

						
						author.setFirstName(firstName);
						author.setMiddleName(middleName);
						author.setLastName(lastName);
						author.setMobileNo(mobileNo);
						
						try {
							ID = authorService.addAuthor(author);
							
							System.out.println("Author ID is : "+ ID);
						} catch (AuthorException e) {
							throw new AuthorException("The details couldnt be added \n" + e.getMessage());
						}
						break;
						
			case 2:
				System.out.println("Enter Author ID : ");
				id = scInput.nextLine();
				ID = Integer.parseInt(id);
				
				try {
					author = authorService.deleteAuthor(ID);
					if(author==null){
						System.out.println("No records found");
					}else{
						System.out.println("Deleted author record is as follows \n" + author);
					}
					
				} catch (AuthorException e) {
					throw new AuthorException("The author couldnt be deleted \n" + e.getMessage());
				} 
				break;
				
			case 3:
				System.out.println("Enter Author ID : ");
				id = scInput.nextLine();
				ID = Integer.parseInt(id);
				
				try {
					author = authorService.findAuthor(ID);
					if(author==null){
						System.out.println("No records found");
					}else{
						System.out.println("Author record is as follows \n" + author);
					}
					
				} catch (AuthorException e) {
					throw new AuthorException("Author couldnt be found \n" + e.getMessage());
				} 
				
					break;
					
			case 4:
				
				try {
					List<Author> list = authorService.viewAllAuhtor();
					
					for(Author authList : list){
						System.out.println(authList);
					}
				} catch (AuthorException e) {
					throw new AuthorException("All Details couldnt be fetched \n" + e.getMessage());

				}
				
					break;
					
			case 5:
				
					System.out.println("Enter Author ID : ");
					id = scInput.nextLine();
					ID = Integer.parseInt(id);
					System.out.println("Enter new Phone No. : ");
					mobileNo = scInput.nextLine();
					
					try {
						author = authorService.updateAuthor(ID, mobileNo);
						System.out.println("Updated author details are as follows\n" + author);
					} catch (AuthorException e) {
						throw new AuthorException("The phone detail couldnt be updated \n" + e.getMessage());
					}
					
					break;
				
			case 6:
					System.out.println("Terminated");
					System.exit(1);
					break;
					
			default :
					System.out.println("Please choose a valid Option");
					break;
		}
		
		}
	
	}

}
